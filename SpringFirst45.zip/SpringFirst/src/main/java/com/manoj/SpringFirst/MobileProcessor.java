package com.manoj.SpringFirst;

public interface MobileProcessor {
void process();
}
