package com.manoj.SpringFirst;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext fact=new AnnotationConfigApplicationContext(AppConfig.class);
       Samsung m30s=fact.getBean(Samsung.class);
       m30s.config();
    }
}
