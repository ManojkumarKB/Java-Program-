import java.util.Comparator;
class Student 
{
	int rollNo,FeesBalance;
	String Name,Cls,BookTkn;
	Student (int rollNo,String Name,String Cls,String BookTkn,int FeesBalance)
	{
		this.rollNo=rollNo;
		this.Name=Name;
		this.Cls=Cls;
		this.BookTkn=BookTkn;
		this.FeesBalance=FeesBalance;
	}
	public void setBooktkn(String roll)
	{
		this.BookTkn=roll;
	}
}
class Sortbyroll implements Comparator<Student>
	{ 
	    public int compare(Student a, Student b) 
	    { 
	        return a.rollNo - b.rollNo; 
	    } 
	} 
