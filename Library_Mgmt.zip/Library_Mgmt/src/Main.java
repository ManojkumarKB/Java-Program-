import java.util.Scanner;
import java.util.Iterator;
import java.util.LinkedList;
public class Main {
	public static LinkedList<Student> st=new LinkedList<Student>();
	public static LinkedList<Book> bk=new LinkedList<Book>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter your role: \n Type \"Admin\" or \" Student\"");
		Scanner sc=new Scanner(System.in);
		String Role=sc.next();
		if(Role.equals(("Admin")))
		{
			int h=9;
			st.add(new Student(1,"Manoj","4year_cse","Java Programming",0));
			st.add(new Student(2,"Kumar","4year_cse","C programming",0));
			st.add(new Student(3,"Arun","3rdyear_cse","C++ programming",0));
			bk.add(new Book(1,"C++ programming","Dennis Ritchie",3,120));
			bk.add(new Book(2,"Java programming","James Patrick",1,150));
			while(h==9)
			{
				System.out.println("Enter the Operation wants to do \n \t  1 for \"Put Student \" \n\t 2 for \"Get Student\"  \n\t 3 for \"Put Book\" \n\t 4 for \"Get Book\"\n");
				System.out.println("Enter -1 to exit");
				h=sc.nextInt();
				if(h==1)
				{		
					System.out.print("Enter the Student Roll No : ");
					int r=sc.nextInt();
					System.out.print("\nEnter the Student Name : ");
					String na=sc.next();
					System.out.println("Enter the Student Class : ");
					String s=sc.next();
					System.out.println("Enter the book student taken");
					String bk=sc.next();
					System.out.println("Enter the Fees balance pending");
					int amt=sc.nextInt();
					st.add(new Student(r,na,s,bk,amt));	
				}
				if(h==2)
				{
					System.out.println("Enter the rollNo to get the details");
					int no=sc.nextInt();
					Iterator it=st.iterator();
					while(it.hasNext())
					{
						Student s=(Student)it.next();
						System.out.println(s.Name);
						if((s.rollNo)==no)
						{
							System.out.format("%s 		: %d\n","Roll No",s.rollNo);
							System.out.format("%s			: %s\n","Name",s.Name);
							System.out.format("%s    		: %s\n","Class",s.Cls);
							System.out.format("%s     		: %s\n","Book Taken",s.BookTkn);
							System.out.format("%s 		: %d\n","Fees Balance",s.FeesBalance);
							//System.out.println(s.rollNo+" "+s.Name+" "+s.Cls+" "+s.BookTkn+" "+s.FeesBalance);
						}
					}
				}
				if(h==3)
				{
					System.out.println("Enter the Book details \n");
					System.out.print("Enter the Book No 	: ");
					int num=sc.nextInt();
					System.out.print("\nEnter the Book Name 	: ");
					String na=sc.nextLine();
					System.out.println("Enter the Book Author : ");
					String s=sc.nextLine();
					System.out.println("Enter the Student name who taken the book");
					int roll=sc.nextInt();
					System.out.println("Enter the Amount of the book : " );
					int amt=sc.nextInt();
					bk.add(new Book(num,na,s,amt,roll));
				}
				if(h==4)
				{
					System.out.println("Enter the book no");
					int num=sc.nextInt();
					Iterator it=bk.iterator();
					while(it.hasNext())
					{
						Book s=(Book)it.next();
						if((s.no)==num)
						{
							System.out.format("%s 	: %d\n","Book No",s.no);
							System.out.format("%s 	: %s\n","Book Name",s.BkName);
							System.out.format("%s 		: %s\n","Author",s.BkAuthor);
							System.out.format("%s 		: %s\n","Amount",s.Amt);
							System.out.format("%s 	: %d\n","Taken by",s.TknBy);
						}
					}
				}
				if(h==-1)
				{
					break;
				}
				h=9;
			}
		}
		if(Role.equals(("Student")))
		{
			int u=9;
			System.out.println("Enter your roll no");
			int r=sc.nextInt();
			Iterator it=st.iterator();
			Student stu=null;
			while(it.hasNext())
			{
				Student s=(Student)it.next();
				if(r==s.rollNo)
				{
					stu=s;
					System.out.println("Roll No\t\t:"+s.rollNo+"\nName\t\t:"+s.Name+"\nClass\t\t:"+s.Cls+"\nBook Taken\t\t:"+s.BookTkn);
				}
			}
			while(u==9)
			{
				System.out.println("Enter the operation needed\t");
				System.out.println("1 to see book list\t");
				System.out.println("2 to borrow the book");
				System.out.println(" 3 to return book");
				System.out.println(" -1 to exit");
				u=sc.nextInt();
				if(u==1)
				{
					System.out.println("Available book are \n");
					Iterator itr=bk.iterator();
					while(itr.hasNext())
					{
						Book b=(Book)itr.next();
						if(b.TknBy==0)
							System.out.println("Book No \t\t: "+b.no+"\nBook Name \t\t: "+b.BkName+"\nAuthor name \t\t: +"+b.BkAuthor+"\nBook amount\t\t"+ b.Amt);
					}
					
				}
				if(u==2)
				{
					System.out.println("Enter the book no to borrow");
					int num=sc.nextInt();
					Iterator itr=bk.iterator();
					while(itr.hasNext())
					{
						Book b=(Book)itr.next();
						if(b.no==num)
						{
							int indBk=bk.indexOf(b);
							int indAl=st.indexOf(stu);
							b.setTknBy(r);
							stu.setBooktkn(b.BkName);
							bk.set(indBk, b);
							System.out.println("The book named\t\t:"+b.BkName+"\nAuthor\t\t:"+b.BkAuthor+"\nAmount\t\t:"+b.Amt+"\n\t\t was borrowed by "+stu.rollNo);
							st.set(indAl,stu);
						}
					}
				}
				if(u==3)
				{
					System.out.println("Enter the book no to return");
					int num=sc.nextInt();
					Iterator itr=bk.iterator();
					while(itr.hasNext())
					{
						Book b=(Book)itr.next();
						if(num==b.no)
						{
							int indBk=bk.indexOf(b.no);
							int indAl=st.indexOf(stu);
							b.setTknBy(r);
							bk.set(indBk, b);
							stu.setBooktkn("");
							st.set(indAl,stu);
							System.out.println("The book named\t\t:"+b.BkName+"\nAuthor\t\t:"+b.BkAuthor+"\nAmount\t\t:"+b.Amt+"\n\t\t was returned by "+stu.rollNo);
						}
					}
				}
				if(u==-1)
				{
					break;
				}
				u=9;
			}
		}
	}
}
