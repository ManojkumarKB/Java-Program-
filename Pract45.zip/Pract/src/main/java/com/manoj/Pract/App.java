package com.manoj.Pract;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.io.*;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
    	/*Vehicle v=(Vehicle)ctx.getBean("bike");
    	v.drive();
    	
    	Tyre t=(Tyre)ctx.getBean("tyre");
    	System.out.println(t);*/
    	Car obj=(Car)ctx.getBean("car");
    	obj.drive();
    }
}
