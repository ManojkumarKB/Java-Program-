package com.manoj.Pract;

public interface Vehicle {
	
	void drive();
}
