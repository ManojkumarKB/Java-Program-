package com.servlets;

import java.util.Iterator;
import java.util.List;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class UploadServlet
 */
@MultipartConfig(maxFileSize = 100000)
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//PrintWriter out=response.getWriter();
		 int num=0;
	   //   out.println(request.getParameter("no"));
	      if(request.getParameter("no")!=null)
	    	  num=Integer.parseInt(request.getParameter("no"));
	  //    out.println(request.getParameter("name"));
	      String name=request.getParameter("name");
	      Part filePart=request.getPart("photo");
	//      out.println(request.getPart("name"));
	     // out.print("Inserting the number"+num+" for "+name);
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			 String mysqlUrl = "jdbc:mysql://localhost/ImgUpl?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	      Connection con = DriverManager.getConnection(mysqlUrl, "root", "");
	      if(con!=null)
	      {
	      System.out.println("Connection established successfully");
	      InputStream in=null;
	      if(filePart!=null)
	      {
	    	  long fileSize=filePart.getSize();
	   // 	  out.println(fileSize);
	    	  String fileContent=filePart.getContentType();
	  //  	  out.println(fileContent); 
	    	  String fname=filePart.getName();
	   // 	  out.println(fname);
	    	  in=filePart.getInputStream();
	      }
	    	  PreparedStatement pstmt = con.prepareStatement("INSERT INTO ImageUpload VALUES(?, ?, ?)");
	    	  pstmt.setInt(1,num);
	    	  pstmt.setString(2, name);
	    //Inserting Blob type
	    //	  in = new FileInputStream("C:/Users/Trainee/eclipse-workspace/Task19/vtg.png");
	    	  if(in!=null)
	    		pstmt.setBlob(3, in);
	    	//  out.print("Inserting the number"+num+" for "+name+" and the image "+filePart);
	    	 // pstmt.execute();
	    	  int returCode=pstmt.executeUpdate();
	    	  if(returCode==0)
	    	  {
	    		  //out.print("Error occured");
	    	  }
	    	  else
	    	  {
		/*request.setAttribute("Message","Your record inserted successfully");
		getServletContext().getRequestDispatcher("/sucess.jsp").forward(request,response);
	      	System.out.println("Record Inserted Sucessfullly");*/
	    		//  out.print("Inserted into database");
	    	  }
	    	  if (!ServletFileUpload.isMultipartContent(request)) 
	    	  {
	            // if not, we stop here
	            PrintWriter writer = response.getWriter();
	            writer.println("Error: Form must has enctype=multipart/form-data.");
	            writer.flush();
	            return;
	    	  }
	    	  FileItemFactory factory = new DiskFileItemFactory();

	   // Set factory constraints
	   // factory.setSizeThreshold(yourMaxMemorySize);
	   // factory.setRepository(yourTempDirectory);

	   // Create a new file upload handler
	    	  ServletFileUpload upload = new ServletFileUpload( factory );
	   // upload.setSizeMax(yourMaxRequestSize);

	   // Parse the request
	    	 /* List<FileItem> uploadItems = upload.parseRequest( request );
	    	  Iterator<FileItem> iter = uploadItems.iterator();
	    	  while (iter.hasNext()) {
	  		  FileItem item = iter.next();
	  		  if (item.isFormField())
	  		  {
	  		    processFormField(item);
              }
	  		  else
	  		  {
	  			  processUploadedFile(item);
	  		  }*/
	    	  Blob image=null;
	    	  byte[ ] imgData = null ;
	    	  Statement stmt = con.createStatement();
	    	  ResultSet rs = stmt.executeQuery("select image from ImageUpload where No = '"+ num +"'");
	    	  if (rs.next())
	    	  {
	    		  image = rs.getBlob(1);
	    		  imgData = image.getBytes(1,(int)image.length());
	    	  }
	    	  else
	    	  {
	    	//	  out.println("Display Blob Example");
	    		//  out.println("image not found for given id>");
	    	  }
	    	// display the image
	    	  response.setContentType("image/jpg");
	    	  OutputStream o = response.getOutputStream();
	    	  o.write(imgData);
	    	  o.flush();
	    	  
	    	  o.close();
	    	  } 
	    	  else
	    	  {
	    		  System.out.println("Connection not established");
	    	  }
	      }
		  catch(Exception e)
		   {
			    e.printStackTrace();
			}
	      }
}