package com.servlet;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.google.gson.Gson;
@WebServlet(name="FileUploadServlet",urlPatterns={"/FileUploadServlet"})
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB
public class FileUploadServlet extends HttpServlet {
    /**
     * Name of the directory where uploaded files will be saved, relative to
     * the web application directory.
     */
	private final static Logger LOGGER = 
            Logger.getLogger(FileUploadServlet.class.getCanonicalName());
    private static final String SAVE_DIR = "uploadFiles";
     
    /**
     * handles file upload
     */
    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        // gets absolute path of the web application
       /* String appPath = request.getServletContext().getRealPath("");
        // constructs path of the directory to save uploaded file
        String savePath = appPath + File.separator + SAVE_DIR;
         
        // creates the save directory if it does not exists
        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists())
        {
            fileSaveDir.mkdir();
        }
        for (Part part : request.getParts())
        {
            String fileName = extractFileName(part);
            // refines the fileName in case it is an absolute path
            fileName = new File(fileName).getName();
            part.write(savePath + File.separator + fileName);
        }
       /* request.setAttribute("message", "Upload has been done successfully!");
        getServletContext().getRequestDispatcher("/message.jsp").forward(
                request, response);
        response.setContentType("text");
        response.getWriter().print("uploaded successfully");*/
    	 Part filePart=request.getPart("file");
    	 String applicationPath = getServletContext().getRealPath(""),	uploadPath = applicationPath + File.separator + "image_uploaded";
    	 if(filePart!=null)
    	 {
    		 System.out.println("Multipart sended successfully");
    	 }
    	 else
    	 {
    		 System.out.println("Not a multipaer3 type");
    	 }
	       // String path="\\image_uploaded",ot="";
	        String ot="";
	        final String fileName = getFileName(filePart);

	        OutputStream out = null;
	        InputStream filecontent = null;
	        final PrintWriter writer = response.getWriter();
	        try 
	        {
	            out = new FileOutputStream(new File(uploadPath + File.separator + fileName));
	            filecontent = filePart.getInputStream();
	            int read = 0;
	            final byte[] bytes = new byte[1024];

	            while ((read = filecontent.read(bytes)) != -1) {
	                out.write(bytes, 0, read);
	            }
	            //writer.println("New file " + fileName + " created at " + path);
	            ot=ot+File.separator+fileName;
	            response.setContentType("text/html");
	           
	        
	          /*  Map<String,Object> hm=new HashMap<String,Object>();
		        hm.put("Image", ot);
		        response.setContentType("application/json");
		        response.setCharacterEncoding("UTF-8");
		        response.getWriter().write(new Gson().toJson(hm));*/
	          /* response.setContentType("image/jpeg");
	            ServletContext sc = getServletContext();
	            InputStream is = sc.getResourceAsStream(ot);
	            ServletOutputStream os = response.getOutputStream();
	            BufferedInputStream bin = new BufferedInputStream(is);  
	            BufferedOutputStream bout = new BufferedOutputStream(os);  
	           
	            int ch =0; ;  
	            while((ch=bin.read())!=-1)  
	            {  
	            bout.write(ch);  
	            }  */
	           /* Blob image=null;
	            response.setContentType("image/jpg");
	            File it = new File(ot);
	            InputStream in=new FileInputStream(it);
	            byte[ ] imgData =null;
	            image=(Blob) in;
	            try 
	            {
					imgData = image.getBytes(1,(int)image.length());
				}
	            catch (SQLException e) 
	            {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		    	  OutputStream o = response.getOutputStream();
		    	  o.write(imgData);*/
	            response.setContentType("text");
	            response.getWriter().write(ot);
	          /*  byte[] buffer = new byte[1024];
	            int bytesRead;


	            while ((bytesRead = is.read(buffer)) != -1) {

	                os.write(buffer, 0, bytesRead);
	            }*/
	            LOGGER.log(Level.INFO, "File{0}being uploaded to {1}", 
	                    new Object[]{fileName, uploadPath});
	        } 
	        catch (FileNotFoundException fne) {
	            writer.println("You either did not specify a file to upload or are "
	                    + "trying to upload a file to a protected or nonexistent "
	                    + "location.");
	            writer.println("<br/> ERROR: " + fne.getMessage());

	            LOGGER.log(Level.SEVERE, "Problems during file upload. Error: {0}", 
	                    new Object[]{fne.getMessage()});
	        } finally {
	            if (out != null) {
	                out.close();
	            }
	            if (filecontent != null) {
	                filecontent.close();
	            }
	            if (writer != null) {
	                writer.close();
	            }
	        }
	        
	    }

	    private String getFileName(final Part part) {
	        final String partHeader = part.getHeader("content-disposition");
	        LOGGER.log(Level.INFO, "Part Header = {0}", partHeader);
	        for (String content : part.getHeader("content-disposition").split(";")) {
	            if (content.trim().startsWith("filename")) {
	                return content.substring(
	                        content.indexOf('=') + 1).trim().replace("\"", "");
	            }
	        }
	        return null;
	    }
}