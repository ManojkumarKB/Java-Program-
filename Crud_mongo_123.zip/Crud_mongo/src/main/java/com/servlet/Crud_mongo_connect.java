package com.servlet;

import java.io.IOException;
import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;
import com.mongodb.MongoClient;


/**
 * Servlet implementation class Crud_mongo_connect
 */

@WebServlet(name="Crud_mongo_connect",urlPatterns={"/Crud_mongo_connect"})

public class Crud_mongo_connect extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private static MongoClient mongoy;
	private static DB db;
	private static DBCollection collection;
       
	 private static final Logger LOGGER= Logger.getLogger(Crud_mongo_connect.class.getName());
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Crud_mongo_connect()
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		System.out.println("Entere into servlet");
		InitializeDatabase("localhost",27017);
		switchDB("test1");
		switchCollection("pract1");
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		if(request!=null)
		InsertTest(request);
		String fName=request.getParameter("first_name");
		System.out.println(fName+" ");
		String lName=request.getParameter("last_name");
		System.out.println(lName+" ");
		String email=request.getParameter("email");
		System.out.println(email+" ");
		String phone=request.getParameter("phone");
		System.out.println(phone+" ");
		String Address=request.getParameter("Address");
		System.out.println(Address+" ");
		String City=request.getParameter("City");
		System.out.println(City+" ");
		String State=request.getParameter("State");
		System.out.println(State+" ");
		String Zp_code=request.getParameter("zip");
		System.out.println(Zp_code+" ");
		String gd=request.getParameter("Gender");
		System.out.println(gd+" ");
		String pd=request.getParameter("comments");
		System.out.println(pd+" ");
		String  js=showContentInDocument();
		JSONParser parser = new JSONParser();
		JSONObject json;
		try 
		{
			json = (JSONObject)parser.parse(js);
		}
		catch (ParseException e)
		{
			e.printStackTrace();
		}
		response.getWriter().print(js);
	}
	private static void InitializeDatabase(String host, int port) 
	{
		System.out.println("Initialize database");
		try
		{
			mongoy=new MongoClient(host,port);
		}
		catch(Exception e)
		{
			LOGGER.info("exception occured"+e);
		}
		System.out.println("Db initialized");
	}
	private static void switchDB(String string)
	{
		// TODO Auto-generated method stub
			System.out.println("Switching  DB.....");
			db=mongoy.getDB(string);
	}
	private static void switchCollection(String string)
	{
		// TODO Auto-generated method stub
		if(db!=null)
		{
			System.out.println("Switching collection");
			collection=db.getCollection(string);
		}
	}
	private static String showContentInDocument() 
	{
		// TODO Auto-generated method stub
		System.out.println("");
		System.out.println("show content of current db");
		DBCursor cursor=collection.find();
		String js="{\"result\":[";
		while(cursor.hasNext())
		{
			js=js+(cursor.next())+",";
		}
			js=js.substring(0,js.length()-2);
			js=js+"}]}";
			System.out.println(js);
			//response.getWriter().print(obj);
			return js;
	
	}
	private static void InsertTest(HttpServletRequest request) 
	{
		// TODO Auto-generated method stub
		BasicDBObject document=new BasicDBObject();
		String fName=request.getParameter("first_name");
		System.out.println(fName+" ");
		String lName=request.getParameter("last_name");
		System.out.println(lName+" ");
		String email=request.getParameter("email");
		System.out.println(email+" ");
		String phone=request.getParameter("phone");
		System.out.println(phone+" ");
		String Address=request.getParameter("Address");
		System.out.println(Address+" ");
		String City=request.getParameter("City");
		System.out.println(City+" ");
		String State=request.getParameter("State");
		System.out.println(State+" ");
		String Zp_code=request.getParameter("zip");
		System.out.println(Zp_code+" ");
		String gd=request.getParameter("Gender");
		System.out.println(gd+" ");
		String pd=request.getParameter("comments");
		System.out.println(pd+" ");
		document.put("first_name", fName);
		document.put("last_name", lName);
		document.put("email", email);
		document.put("phone", phone);
		document.put("Address", Address);
		document.put("City", City);
		document.put("State", State);
		document.put("Zp_code", Zp_code);
		document.put("Gender", gd);
		document.put("Project_description", pd);
		
		Insert(document);
		
		LOGGER.info("Document Insert Successfully using Document Obj...");
	}
	private static void Insert(BasicDBObject document)
	{
		System.out.println("Inserting the document.....");
		if(document!=null)
		{
			collection.insert(document);
		}
	}
}
