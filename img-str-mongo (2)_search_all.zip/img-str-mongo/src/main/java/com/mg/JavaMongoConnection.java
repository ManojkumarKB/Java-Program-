package com.mg;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.google.gson.Gson;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
/**
 * Servlet implementation class JavaMongoConnection
 */

@WebServlet(name="JavaMongoConnection",urlPatterns={"/JavaMongoConnection"})
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB



public class JavaMongoConnection extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final static Logger LOGGER = Logger.getLogger(JavaMongoConnection.class.getCanonicalName());
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		//Getting the file 
		 Part filePart=request.getPart("file");
		 String no=request.getParameter("no");
		 String name=request.getParameter("name");
		 String applicationPath = getServletContext().getRealPath("web-resources");
    	 System.out.println(applicationPath);
    	 
    	 String uploadPath =  "C:\\Users\\Trainee\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp0\\wtpwebapps\\img-str-mongo\\img";
		
    	 if(filePart!=null)
    	 {
    		 System.out.println("Multipart sended successfully");
    	 }
    	 
    	 else
    	 {
    		 System.out.println("Not a multipaer3 type");
    	 }
    	 
    	 final String fileName = getFileName(filePart); 
    	 String s="",org="";
    	 OutputStream out = null;
	     InputStream filecontent = null;
	     final PrintWriter writer = response.getWriter();
	     BasicDBObject doc1=null;
	     try 
	     {
	    	 	s="http://localhost:8080/img-str-mongo/img/"+ fileName;
	        	System.out.println("the located path " + s);
	            out = new FileOutputStream(new File(uploadPath + "\\" + fileName));
	            filecontent = filePart.getInputStream();
	            int read = 0;
	            final byte[] bytes = new byte[1024];

	            while ((read = filecontent.read(bytes)) != -1)
	            {
	                out.write(bytes, 0, read);
	            }
	            org=uploadPath + "\\" + fileName;
	            doc1=new BasicDBObject("no",no).append("name",name).append("cpath", org).append("fname", fileName);  
	            
	            MongoClient mongoClient=new MongoClient("localhost",27017);
				System.out.println("Server connection successfully done");
				
				DB d=mongoClient.getDB("img-str");
				System.out.println("Connection Done");
				System.out.println("Db name"+d.getName());
				
				DBCollection coll=d.getCollection("imgpath1");
				System.out.println("Collection created succesfully");
				coll.insert(doc1);
						
				BasicDBObject query = BasicDBObject.parse("{no: {$eq: \""+no+"\"}}");
				DBObject dock= coll.findOne(query);
				String path1 = (String) dock.get( "cpath" );
				
				//The response of all documents into the json object
				String js="{\"result\":[";
				Cursor iterDoc = coll.find(); 
			    while (iterDoc.hasNext())
			    {  
			       js=js+(iterDoc.next())+",";  
			    }
				js=js.substring(0,js.length()-2);
				js=js+"}]}";
				System.out.println(js);
				JSONParser parser = new JSONParser();
				try 
				{
					JSONObject json = (JSONObject) parser.parse(js);
					response.getWriter().print(json);
				/*	try {
						JSONObject json = (JSONObject) parser.parse(js);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
					response.setContentType("application/json");
					response.setCharacterEncoding("UTF-8");
					//response.getWriter().print(obj);
				} 
				catch (ParseException e) {
					e.printStackTrace();
				}
				
				
				
				/*	response by json for searching operation
				Map<String,Object> hm=new HashMap<String,Object>();
		        hm.put("path", org);
		        hm.put("fname","http://localhost:8080/img-str-mongo/img/"+fileName);
		        response.setContentType("application/json");
		        response.setCharacterEncoding("UTF-8");
		        response.getWriter().write(new Gson().toJson(hm));*/
				
				/*responses by text
			    response.setContentType("text");
				response.getWriter().write(path1+"&"+"http://localhost:8080/img/"+fileName);
				System.out.println("path   "+path1);
						
				//writer.println(path1+"  "+"http://localhost:8080/img/"+fileName);
				response.getWriter().write(path1+'&'+s);*/
	        }
	     catch (FileNotFoundException fne)
	     {
	            writer.println("You either did not specify a file to upload or are "
	                    + "trying to upload a file to a protected or nonexistent "
	                    + "location.");
	            writer.println("<br/> ERROR: " + fne.getMessage());

	            LOGGER.log(Level.SEVERE, "Problems during file upload. Error: {0}", 
	                    new Object[]{fne.getMessage()});
	      }
	     finally
	     {
	            if (out != null) {
	                out.close();
	            }
	            if (filecontent != null) {
	                filecontent.close();
	            }
	            if (writer != null) {
	                writer.close();
	            }
		//Connecting with server
				
					
						/*JSONObject obj = new JSONObject();
						obj.put("path",org);
						obj.put("fname", "http://localhost:8080/img-str-mongo/img/"+fileName);*/
						
						/* Map<String,Object> hm=new HashMap<String,Object>();
					        hm.put("path", org);
					        hm.put("fname","http://localhost:8080/img-str-mongo/img/"+fileName);
					        response.setContentType("application/json");
					        response.setCharacterEncoding("UTF-8");
					        response.getWriter().write(new Gson().toJson(hm));*/
					        
					     /*System.out.println("the hashmap is");
					     System.out.println(hm);*/
						//Printinh the values by name
						//System.out.println("wewewe is ");
						//int ch=0;
						/*while(curse.hasNext())
						{
							ch=Integer.parseInt((curse.next().get("no")));
						}*/
						//DBObject dock= coll.findOne(\"no\":\"99\"});
						//String name = (String) dock.get(  );
				 		//retrieving the class path by no
	        }
				
	}
	 private String getFileName(final Part part) {
	        final String partHeader = part.getHeader("content-disposition");
	        LOGGER.log(Level.INFO, "Part Header = {0}", partHeader);
	        for (String content : part.getHeader("content-disposition").split(";")) {
	            if (content.trim().startsWith("filename")) {
	            	//String s=content.substring(content.indexOf('=') + 1).trim().replace('"',"");
	            	
	                return content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
	            }
	        }
	        return null;
	    }

}
