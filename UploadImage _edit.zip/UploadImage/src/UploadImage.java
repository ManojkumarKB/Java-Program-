import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UploadServlet
 */
public class UploadImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			 String mysqlUrl = "jdbc:mysql://localhost/ImgUpl?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	      Connection con = DriverManager.getConnection(mysqlUrl, "root", "");
	      if(con!=null)
	      {
	      System.out.println("Connection established successfully");
	      
	      int no=Integer.parseInt(request.getParameter("no"));
	      Part filePart=request.getPart("Image");
	      System.out.println("Inserting the number"+no+" and the image "+filePart);
	      InputStream in;
	      if(filePart!=null)
	      {
	    	  long fileSize=filePart.getSize();
	    	  String fileContent=filePart.getContentType();
	    	  in=filePart.getInputStream();
	      PreparedStatement pstmt = con.prepareStatement("INSERT INTO ImageUpload VALUES(?, ?)");
	      pstmt.setInt(1,no);
	    //Inserting Blob type
	     /* InputStream in = new FileInputStream("C:/Users/Trainee/eclipse-workspace/Task19/vtg.png");*/
	      pstmt.setBlob(2, in);;
	      pstmt.execute();
	      int returCode=pstmt.executeUpdate();
	      if(returCode==0)
	      {
	    	  request.setAttribute("Message", "Error Inserting file");
	    	  getServletContext().getRequestDispatcher("/sucess.jsp").forward(request, response);;
	      }
	      System.out.println("Record Inserted Sucessfullly");
	      }
	      }
	      else
	      {
	    	  System.out.println("Connection not established");
	      }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
