import java.util.Scanner;
public class FindSecLarge {
		static int arr[];
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements");
		int n=sc.nextInt(),max=0;
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		max=maxNum(arr);
		for(int i=0;i<arr.length;i++)
		{
			if(max==arr[i])
			{
				arr[i]=-1;
			}
		}
		max=maxNum(arr);
		System.out.println("The second largest number is "+max);
	}
	static int maxNum(int[] arr)
	{
		int max=0;
		for(int i=0;i<arr.length;i++)
		{
			if(max<arr[i])
			{
				max=arr[i];
			}
		}
		return max;
	}
}