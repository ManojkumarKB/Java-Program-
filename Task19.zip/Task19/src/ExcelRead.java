import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;;

public class ExcelRead
{
	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		//writeIntoExcel("birthdays.xlsx"); 
		readFromExcel("book.xlsx");
	}
	public static void readFromExcel(String file) throws IOException
	{
		
		ArrayList<ArrayList> st=new ArrayList<ArrayList>();
		File fil=new File(file);
		FileInputStream f	= new FileInputStream(file);
		XSSFWorkbook myExcelBook = new XSSFWorkbook(f);
		if(fil.isFile()&&(fil.exists()))
		{
			System.out.println("The file exist");
		}
		else
		{
			System.out.println("Not found");
		}
		XSSFSheet myExcelSheet = myExcelBook.getSheetAt(0);
		java.util.Iterator<Row> itr = myExcelSheet.iterator();
	    while (itr.hasNext()) 
	    {
	    	ArrayList data = new ArrayList();
	        Row rowitr = (Row) itr.next();
	        java.util.Iterator<Cell> cellitr = rowitr.cellIterator();
	        while(cellitr.hasNext()) 
	        {
	            Cell celldata = (Cell) cellitr.next();

	            switch(celldata.getCellType()) 
	            {
	            case STRING:
	                data.add(celldata.getStringCellValue());
	                System.out.print(celldata.getStringCellValue()+" ");
	                break;
	            case NUMERIC:
	                data.add(celldata.getNumericCellValue());
	                System.out.print((celldata.getNumericCellValue())+" ");
	                break;
	            	
	            
	            }
	            
	        }
	        System.out.println();
	        st.add(data);
	    }
	    for(ArrayList al:st)
	    {
	    	System.out.println(al);
	    }
	}
}