package com.mg;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.servlet.FileUploadServlet;

/**
 * Servlet implementation class JavaMongoConnection
 */

@WebServlet(name="JavaMongoConnection",urlPatterns={"/JavaMongoConnection"})
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB
private final static Logger LOGGER = 
Logger.getLogger(FileUploadServlet.class.getCanonicalName());
public class JavaMongoConnection extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public JavaMongoConnection() {
        // TODO Auto-generated constructor stub
    }
    
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//Getting the file 
		Part filePart=request.getPart("file");
		String no=request.getParameter("no");
		String name=request.getParameter("name");
		 String applicationPath = getServletContext().getRealPath("web-resources");
    	 System.out.println(applicationPath);
    	 
    	 String uploadPath =  "C:\\Users\\Trainee\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\LocImgUpl\\img";
		
    	 if(filePart!=null)
    	 {
    		 System.out.println("Multipart sended successfully");
    	 }
    	 else
    	 {
    		 System.out.println("Not a multipaer3 type");
    	 }
    	 
    	 final String fileName = getFileName(filePart); 
    	 String s="",org="";
    	 OutputStream out = null;
	        InputStream filecontent = null;
	        final PrintWriter writer = response.getWriter();
	        try 
	        {
	        	 s="http://localhost:8083/LocImgUpl/img/"+ fileName;
	        	System.out.println("the located path " + s);
	            out = new FileOutputStream(new File(uploadPath + "\\" + fileName));
	            filecontent = filePart.getInputStream();
	            int read = 0;
	            final byte[] bytes = new byte[1024];

	            while ((read = filecontent.read(bytes)) != -1)
	            {
	                out.write(bytes, 0, read);
	            }
	            org=uploadPath + "\\" + fileName;
	            BasicDBObject doc1=new BasicDBObject("no",no).append("name",name).append("cpath", org);
	        }
	        catch (FileNotFoundException fne) {
	            writer.println("You either did not specify a file to upload or are "
	                    + "trying to upload a file to a protected or nonexistent "
	                    + "location.");
	            writer.println("<br/> ERROR: " + fne.getMessage());

	            LOGGER.log(Level.SEVERE, "Problems during file upload. Error: {0}", 
	                    new Object[]{fne.getMessage()});
	        } finally {
	            if (out != null) {
	                out.close();
	            }
	            if (filecontent != null) {
	                filecontent.close();
	            }
	            if (writer != null) {
	                writer.close();
	            }
	        }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		//Connecting with server
				MongoClient mongoClient=new MongoClient("localhost",27017);
				System.out.println("Server connection successfully done");
				
				//Connecting with database
				/*MongoDatabase dbs=mongoClient.getDatabase("test");
				System.out.println("Connect to db successfully");
				System.out.println("Db name "+dbs.getName());*/
				
				/*Displaying all databses in the server
				List<String> dbNames=mongoClient.getDatabaseNames();
				System.out.println(dbNames);*/
				
				/*MongoDatabase db=mongoClient.getDatabase("mongo-crud-java-eg");
				System.out.println("Connection Done");
				System.out.println("Db name"+db.getName());*/
				
				DB d=mongoClient.getDB("img-str");
				System.out.println("Connection Done");
				System.out.println("Db name"+d.getName());
				
				DBCollection coll=d.getCollection("imgpath1");
				System.out.println("Collection created succesfully");
				coll.insert(doc1);
				/*BasicDBObject doc1=new BasicDBObject("name","manoj").append("cpath", "C:\\Users\\Trainee\\Downloads\\download1.jpg");
				coll.insert(doc1);
				System.out.println("Document Inserted");
				
				BasicDBObject doc2=new BasicDBObject("name","kohli").append("cpath", "C:\\Users\\Trainee\\Downloads\\download2.jpg");
				coll.insert(doc2);
				System.out.println("Document Inserted");*/
				
				Cursor curse=coll.find();
				//Printinh the values by name
				while(curse.hasNext())
				{
					System.out.println(curse.next().get("name"));
				}
	}
	 private String getFileName(final Part part) {
	        final String partHeader = part.getHeader("content-disposition");
	        LOGGER.log(Level.INFO, "Part Header = {0}", partHeader);
	        for (String content : part.getHeader("content-disposition").split(";")) {
	            if (content.trim().startsWith("filename")) {
	            	//String s=content.substring(content.indexOf('=') + 1).trim().replace('"',"");
	            	
	                return content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
	            }
	        }
	        return null;
	    }

}
