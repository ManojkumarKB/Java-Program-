package com.servlet;

import java.util.Iterator;
import java.util.List;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 * Servlet implementation class UploadServlet
 */
@MultipartConfig(maxFileSize = 100000)
public class process_img extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String n=request.getParameter("no");
		//out.println("the string "+n);
		String na=request.getParameter("name");
		String ur=request.getParameter("ph");
		//out.println("ur");
	   if(n==null || n.trim().equals("") || na==null || na.trim().equals(""))
	   {
		  System.out.println("Enter id");
	   }
	   else
	   {
		    try{
		   			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
					String mysqlUrl = "jdbc:mysql://localhost/ImgUpl?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		   			Connection con = DriverManager.getConnection(mysqlUrl, "root", "");
		   			int num=0;
		   			//out.print("The no is "+Integer.parseInt(n));
		   	        num=Integer.parseInt(n);
			        //Part filePart=request.getPart("ph");
			       //out.println(request.getPart("ph"));
			       //out.println(filePart);
		   			if(con!=null)
		        	{
		      			System.out.println("Connection established successfully");
		      	  		PreparedStatement pstmt = con.prepareStatement("INSERT INTO image_new VALUES(?, ?, ?)");
		      	 		pstmt.setInt(1,num);
		    	  		pstmt.setString(2, na);
		    	  		pstmt.setString(3,ur);
		       	  		//	InputStream in=null;
		    	  		//in=filePart.getInputStream();
		    	 	 	//	if(in!=null)
			     		//	pstmt.setBlob(3, in);
		    	  			int returCode=pstmt.executeUpdate();
		    	  		//	int returCode=0;
			    		if(returCode==0)
			    			{
			    				//out.print("Error occured");
			    		 }
			    		else
			    			/* else
			    			 {
			    	 			if (!ServletFileUpload.isMultipartContent(request)) 
			    	  			{
			            		// if not, we stop here
			            			PrintWriter writer = response.getWriter();
			            			writer.println("Error: Form must has enctype=multipart/form-data.");
			            			writer.flush();
			            			return;
			    	  			}
			    	 			
			    	  			FileItemFactory factory = new DiskFileItemFactory();
			    	  			ServletFileUpload upload = new ServletFileUpload( factory );*/
			    	  			//Blob image=null;
			    	  			//byte[ ] imgData = null ;
			    	  	{
			    	  		//out.println("Insertion successfull");
			    	  		Statement stmt = con.createStatement();
			    	  		ResultSet rs = stmt.executeQuery("select image from image_new where no = '"+ num +"'");		    	  
			    	  			/* (rs.next())
			    	  			{
			    		  			image = rs.getBlob(1);
			    		  			imgData = image.getBytes(1,(int)image.length());
			    		  		}*/
			    	  			//System.out.println(imgData);
			    		 		//response.setContentType("text/xml");
				    	  		//OutputStream o = response.getOutputStream();
				    	  		//response.setContentType("text/xml");
				    	  		//response.getWriter().write("<IMAGE></IMAGE>");
				    	  		//o.write(imgData);
				    	  		//o.flush();
				    	  		//o.close();
				    	  		//out.println(rs.getString(1));
				    	  	response.setContentType("text/xml");
				    	  	if(rs.next())
				    	  	{
				    	  		response.getWriter().write("<IMAGE>" + rs.getString(1) + "</IMAGE>");
				    	  	}
				    	}
			    			 }
					else
					{
				    	System.out.println("Connection not established");
					}
				}
			catch(Exception e)
			{
			    e.printStackTrace();
			}
		}
}
}