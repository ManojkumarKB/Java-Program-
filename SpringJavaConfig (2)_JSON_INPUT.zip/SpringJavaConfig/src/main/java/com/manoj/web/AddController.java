package com.manoj.web;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AddController {
	
	//@PostMapping(produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	/*@RequestMapping(value = "/add", method = {RequestMethod.POST},consumes = {"application/json"})
	public ModelAndView add(@RequestBody Num n)
	{
		ModelAndView mv=new ModelAndView();
		/*int k=t1+t2;
		mv.addObject("result",k);
		mv.setViewName("result.jsp");
		
		System.out.println(n);
		return mv;
	}*/
	@PostMapping(path="/add",consumes="application/json", produces = "application/json")
	//@RequestMapping(value = "/add", method = {RequestMethod.POST})
	public Num[] add(@Validated @RequestBody Num[] n)
	{
		for(int j=0;j<n.length;j++)
		{
			int asum=0,sum=0;
			sum=n[j].gettxt1()+n[j].gettxt2()+n[j].gettxt3();
			n[j].setResult(sum);
			int a[]=n[j].getArr();
			for(int i=0;i<n[j].getArr().length;i++)
			{
				asum=asum+a[i];
			}
			n[j].setArrResult(asum);
		}
		return n;
	}
	

}
