package com.manoj.web;

public class Num {
	public int txt1;
	public int txt2;
	public int txt3;
	public int[] arr;
	public int result;
	public int arrResult;
	public int getArrResult() {
		return arrResult;
	}
	public void setArrResult(int arrResult) {
		this.arrResult = arrResult;
	}
	public int[] getArr() {
		return arr;
	}
	public void setArr(int[] arr) {
		this.arr = arr;
	}
	public int gettxt1() {
		return txt1;
	}
	public void settxt1(int txt1) {
		this.txt1 = txt1;
	}
	public int gettxt2() {
		return txt2;
	}
	public void settxt2(int txt2) {
		this.txt2 = txt2;
	}
	public int gettxt3() {
		return txt3;
	}
	public void settxt3(int txt3) {
		this.txt3 = txt3;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
}
